class Cart {
    constructor() {
        this.items = {}
        this.total = 0
    }

    async refresh_cart() {
        this.total = 0
        cart_html.innerHTML = ""
        for (let item_id in this.items) {
            if (this.items[item_id] > 0) {
                this.total += (drinks[item_id].price * this.items[item_id])
                add_blank(cart_html, cart_item_blank, {
                    'cart_item_id': item_id,
                    'drink_name': drinks[item_id].drink_name,
                    'drink_count': this.items[item_id],
                    'price': drinks[item_id].price.toFixed(2),
                    'item_total': (drinks[item_id].price * this.items[item_id]).toFixed(2),
                }).then(() => {
                    let el = document.getElementById("remove-item-" + item_id)
                    el.addEventListener('click', function () {
                        cart.remove_item(item_id)
                    })
                })
            }
        }
        this.refresh_prices()
    }

    async clear() {
        cart_html.innerHTML = ""
        this.items = {}
        await this.refresh_cart()
    }

    refresh_prices() {
        total_price_html.innerHTML = total_price_blank.replace('{total_price}', this.total.toFixed(2))
        fill_profile().then()
    }

    add_item(item_id) {
        if (item_id in this.items) {
            this.items[item_id]++
        } else {
            this.items[item_id] = 1
        }
        this.refresh_cart().then(r => {
        })
    }

    remove_item(item_id) {
        if (item_id in this.items) {
            this.items[item_id]--;
        } else {
            alert("irgendwas ist kaputt\nFeuerlöscher bereit halten!")
        }
        this.refresh_cart().then(r => {
        })
    }
}