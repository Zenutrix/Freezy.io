
const popup_html = document.getElementById("popup")

async function popup(title, msg) {
    popup_html.innerHTML = popup_blank
    popup_html.innerHTML = popup_html.innerHTML.replaceAll('{popup_title}', title)
    popup_html.innerHTML = popup_html.innerHTML.replaceAll('{popup_message}', msg)
    fade()
}