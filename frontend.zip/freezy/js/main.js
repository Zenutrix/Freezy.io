const api_host = "127.0.0.1"
const api_port = 8080
const api_url = "http://" + api_host + ":" + api_port

const debug = true;
if (!debug) {
    console.log = () => {}
}

load_blanks().then(() => {
    load_drinks().then(() => {
        fill_drinks().then(() => {
            add_drink_listeners();
            wait_for_user().then();
        })
    })
})



