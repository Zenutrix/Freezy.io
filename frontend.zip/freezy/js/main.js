// const api_host = "192.168.1.5"
const api_host = "127.0.0.1"
const api_port = 80
const api_url = "http://" + api_host + ":" + api_port + "/api"

const debug = true;
if (!debug) {
    console.log = () => {
    }
    console.error = () => {
    }
    console.exception = () => {
    }
    console.debug = () => {
    }
    console.trace = () => {
    }
    console.warn = () => {
    }
}

function run() {
    load_blanks().then(() => {
        load_drinks().then(() => {
            fill_drinks().then(() => {
                add_drink_listeners();
                wait_for_user().then();
            })
        }).catch(() => {
            setTimeout(run, 3000)
        })
    })
}

function connection_failed() {
    // TODO show connection failed popup
}

run()
