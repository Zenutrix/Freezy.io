/** slide animation for overlay (plays after login)
 * @param direction normal or reverse to slide out or in
 * @param hide_after
 */
function slide(direction = "normal", hide_after = true) {
    overlay_html.style.visibility = ""
    let a = document.getElementById("overlay").animate([
        // keyframes
        {transform: 'translateY(0%)'},
        {transform: 'translateY(-100%)'}
    ], {
        // timing options
        duration: 400,
        iterations: 1,
        direction: direction
    });
    a.onfinish = () => {
        overlay_html.style.visibility = hide_after ? "hidden" : "visible";
    }
}

function fade(direction = "normal") {
    let a = document.getElementById("popup").animate([
        {opacity: '0', transform: "translate(-50%, -40%)"},
        {opacity: '1', transform: "translate(-50%, -50%)"},
    ], {
        duration: 300,
        iterations: 1,
        direction: direction,
    })
}

