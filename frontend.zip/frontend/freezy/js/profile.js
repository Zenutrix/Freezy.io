/** fills the profile card with*/
async function fill_profile() {
    profile_html.innerHTML = ""
    await add_blank(profile_html, profile_blank, {
        'user_name': current_user.username,
        'serial': current_user.serial,
        'credit': current_user.credit.toFixed(2),
        'credit_after_purchase': (current_user.credit - cart.total).toFixed(2)
    }).then(() => {
        document.getElementById("purchase_btn").onclick = (event) => purchase(event)
        document.getElementById("logout_btn").onclick = (event) => logout()
    })
}

/** computes and sends purchase request */
function purchase(event) {
    if (Object.keys(cart.items).length === 0) {
        // cart empty error/popup/shake animation
    } else {
        let post_data = {
            "user_id": current_user.user_id,
            "total_price": cart.total,
            "drinks": cart.items
        }

        fetch(api_url + "/purchase", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': api_host,
            },
            body: JSON.stringify(post_data)
        }).then(async res => {
            let json = await res.json()
            if (json['status'] === 'ok') {
                current_user.credit -= cart.total
                cart.clear().then()
                popup("purchase successful", "you will be logged out in 3 seconds").then(r => {})
                setTimeout(logout, 2500)
            } else if (json['status'] === 'error') {
                console.log("[ERROR]", json['error'] + ":", json['msg'])
            }
        })
    }
}

function logout() {
    slide("reverse", false)
    let post_data = {
        "user_id": current_user.user_id,
    }

    fetch(api_url + "/logout", {
        method: "POST",
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': api_host,
        },
        body: JSON.stringify(post_data)
    }).then(async res => {
        let json = await res.json()
        if (json['status'] === 'ok') {
            current_user = null;
        } else if (json['status'] === 'error') {
            console.log("[ERROR]", json['error'] + ":", json['msg'])
        }
    }).then(() => {
        wait_for_user().then();
        popup_html.innerHTML = ""
    })
}