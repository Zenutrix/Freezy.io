/** blanks */
let cart_item_blank, drink_blank, profile_blank, total_price_blank, popup_blank;

/** html elements */
const overlay_html = document.getElementById("overlay");
const drinks_html = document.getElementById("drinks")
const cart_html = document.getElementById("cart")
const profile_html = document.getElementById("profile")
const total_price_html = document.getElementById("total-price")

/** global variables */
const drinks = []
const cart = new Cart()
let current_user = null;

/** gets json data from url */
async function get_json(url) {
    return await (await fetch(url)).json()
}

/** gets raw text data from url */
async function get_text(url) {
    try {
        return (await fetch(url)).text();
    } catch (err) {
        console.log(err)
    }
}

/** adds a blank to html target and replaces placeholders with values
 * @param target some html element
 * @param blank preloaded blank text
 * @param values values for placeholders
 */
async function add_blank(target, blank, values) {
    for (let key in values) {
        blank = blank.replaceAll('{' + key + '}', values[key])
    }
    target.innerHTML += blank;
}

/** loads the blank templates */
async function load_blanks() {
    cart_item_blank = await get_text("../blank/cart_item.blnk");
    drink_blank = await get_text("../blank/drink.blnk");
    profile_blank = await get_text("../blank/profile.blnk");
    total_price_blank = await get_text("../blank/total_price.blnk");
    popup_blank = await get_text("../blank/popup.blnk");
}

/** loads the drinks */
async function load_drinks() {
    let drinks_json = await get_json(api_url + "/get_all_drinks")
    for (let d of drinks_json.values()) {
        drinks.push(new Drink(d.drink_id, d.drink_name, d.price, d.description));
    }
}

/** fills the list of drinks with drink-blanks using the loaded drink data*/
async function fill_drinks() {
    for (let drink of drinks.values()) {
        await add_blank(drinks_html, drink_blank, {
            'drink_id': drink.drink_id,
            'drink_name': drink.drink_name,
            'price': drink.price.toFixed(2)
        })
    }
}

/** adds the button listener to the drink-blanks */
function add_drink_listeners() {
    let add_buttons = document.getElementsByClassName("add-drink-to-cart")
    for (let i = 0; i < add_buttons.length; i++) {
        add_buttons[i].addEventListener('click', function () {
            let drink_id = add_buttons[i].parentElement.id.split('-')[1] - 1
            cart.add_item(drink_id)
        })
    }
}

/** waits until a user scans their MIFARE tag */
async function wait_for_user() {
    let obj = await get_json(api_url + "/get_current_user")
    if (obj != null) {
        // TODO maybe handle unknown user error instead of ignoring them.
        current_user = obj
        cart.refresh_prices()
        slide()
    } else {
        setTimeout(wait_for_user, 2000);
    }
}