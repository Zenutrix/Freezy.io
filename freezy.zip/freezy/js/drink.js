class Drink {
    constructor(drink_id, drink_name, price, description) {
        this.drink_id = drink_id;
        this.drink_name = drink_name
        this.price = price;
        this.description = description;
    }
}