
const popup_html = document.getElementById("popup")

async function popup(title, msg) {
    popup_html.innerHTML = await get_text("../blank/popup.blnk");
    popup_html.innerHTML = popup_html.innerHTML.replaceAll('{popup_title}', title)
    popup_html.innerHTML = popup_html.innerHTML.replaceAll('{popup_message}', msg)
}